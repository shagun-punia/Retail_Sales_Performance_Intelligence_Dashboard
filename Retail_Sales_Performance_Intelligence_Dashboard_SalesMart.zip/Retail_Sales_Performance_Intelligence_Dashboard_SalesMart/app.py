import streamlit as st
import pandas as pd
import plotly.express as px
st.markdown("""
<style>
.stApp {
    background-color: #07111f;
    //color: white;
}

h1, h2, h3, p, label {
    color: white !important;
}

div[data-testid="metric-container"] {
    background-color: #101b33;
    border: 1px solid #2f80ed;
    padding: 18px;
    border-radius: 15px;
}

div[data-testid="metric-container"] label {
    color: #9cc9ff !important;
}

div[data-testid="metric-container"] div {
    color: white !important;
}

section[data-testid="stSidebar"] {
    background-color: #101b33;
}

section[data-testid="stSidebar"] * {
    color: white !important;
}
</style>
""", unsafe_allow_html=True)
st.markdown(
    """
    <style>
    .stApp {
        background-color: #07111f;
        color: white;
    }
    </style>
    """,
    unsafe_allow_html=True
)
# ------------------------------------------------
# PAGE CONFIG
# ------------------------------------------------
st.set_page_config(
    page_title="Retail Intelligence Dashboard",
    layout="wide"
)

# ------------------------------------------------
# LOAD DATA
# ------------------------------------------------
df = pd.read_csv("outputs/final_advanced_retail_sales.csv")

# ------------------------------------------------
# TITLE
# ------------------------------------------------
st.title("Retail Sales & Profit Optimization Intelligence Dashboard")

st.markdown("### Python Pandas Major Project | 100000 Records")
st.markdown(
    """
    <style>
    div[data-testid="metric-container"] {
        background-color: #101b33;
        border: 1px solid #2f80ed;
        padding: 15px;
        border-radius: 12px;
    }
    </style>
    """,
    unsafe_allow_html=True
)
# ------------------------------------------------
# SIDEBAR FILTERS
# ------------------------------------------------
st.sidebar.header("Filters")
st.sidebar.success("Interactive Business Filters")
region = st.sidebar.multiselect(
    "Select Region",
    options=df["Region"].unique(),
    default=df["Region"].unique()
)

category = st.sidebar.multiselect(
    "Select Category",
    options=df["Category"].unique(),
    default=df["Category"].unique()
)

# ------------------------------------------------
# FILTER DATA
# ------------------------------------------------
filtered_df = df[
    (df["Region"].isin(region)) &
    (df["Category"].isin(category))
]

# ------------------------------------------------
# KPI CARDS
# ------------------------------------------------
total_sales = filtered_df["Sales_Amount"].sum()
total_profit = filtered_df["Profit"].sum()
total_orders = filtered_df["Order_ID"].nunique()
avg_profit = filtered_df["Profit_%"].mean()

col1, col2, col3, col4 = st.columns(4)

col1.metric("Total Sales", f"₹ {total_sales:,.0f}")
col2.metric("Total Profit", f"₹ {total_profit:,.0f}")
col3.metric("Total Orders", total_orders)
col4.metric("Avg Profit %", f"{avg_profit:.2f}%")

# ------------------------------------------------
# REGION SALES
# ------------------------------------------------
region_sales = filtered_df.groupby("Region")["Sales_Amount"].sum().reset_index()

fig1 = px.bar(
    region_sales,
    x="Region",
    y="Sales_Amount",
    title="Regional Revenue Performance",
    color="Region"
)

# ------------------------------------------------
# CATEGORY PROFIT
# ------------------------------------------------
category_profit = filtered_df.groupby("Category")["Profit"].sum().reset_index()

fig2 = px.bar(
    category_profit,
    x="Category",
    y="Profit",
    title="Category Profitability Analysis",
    color="Category"
)

# ------------------------------------------------
# MONTHLY TREND
# ------------------------------------------------
monthly_sales = filtered_df.groupby("Year_Month")["Sales_Amount"].sum().reset_index()

fig3 = px.line(
    monthly_sales,
    x="Year_Month",
    y="Sales_Amount",
    title="Monthly Sales Trend",
    markers=True
)

# ------------------------------------------------
# TOP PRODUCTS
# ------------------------------------------------
top_products = (
    filtered_df.groupby("Product_Name")["Sales_Amount"]
    .sum()
    .sort_values(ascending=False)
    .head(10)
    .reset_index()
)

fig4 = px.bar(
    top_products,
    x="Sales_Amount",
    y="Product_Name",
    orientation="h",
    title="Top Products"
)

# ------------------------------------------------
# SHOW CHARTS
# ------------------------------------------------
fig1.update_layout(
    template="plotly_dark",
    paper_bgcolor="#101b33",
    plot_bgcolor="#101b33",
    font_color="white",
    title_font_color="white",
    xaxis=dict(title_font=dict(color="white"),
               tickfont=dict(color="white")),
    yaxis=dict(title_font=dict(color="white"),
               tickfont=dict(color="white"))
)

fig2.update_layout(
    template="plotly_dark",
    paper_bgcolor="#101b33",
    plot_bgcolor="#101b33",
    font_color="white",
    title_font_color="white",
    xaxis=dict(title_font=dict(color="white"),
               tickfont=dict(color="white")),
    yaxis=dict(title_font=dict(color="white"),
               tickfont=dict(color="white"))
)

fig3.update_layout(
    template="plotly_dark",
    paper_bgcolor="#101b33",
    plot_bgcolor="#101b33",
    font_color="white",
    title_font_color="white",
    xaxis=dict(title_font=dict(color="white"),
               tickfont=dict(color="white")),
    yaxis=dict(title_font=dict(color="white"),
               tickfont=dict(color="white"))
)

fig4.update_layout(
    template="plotly_dark",
    paper_bgcolor="#101b33",
    plot_bgcolor="#101b33",
    font_color="white",
    title_font_color="white",
    xaxis=dict(title_font=dict(color="white"),
               tickfont=dict(color="white")),
    yaxis=dict(title_font=dict(color="white"),
               tickfont=dict(color="white"))
)
c1, c2 = st.columns(2)

c1.plotly_chart(fig1, use_container_width=True)
c2.plotly_chart(fig2, use_container_width=True)

c3, c4 = st.columns(2)

c3.plotly_chart(fig3, use_container_width=True)
c4.plotly_chart(fig4, use_container_width=True)

# ------------------------------------------------
# SMART RECOMMENDATIONS
# ------------------------------------------------
st.subheader("Smart Business Recommendations")

recommendation_count = filtered_df["Smart_Recommendation"].value_counts()

st.dataframe(recommendation_count)


# ------------------------------------------------
# LOSS AMOUNT BY PRODUCT
# ------------------------------------------------

st.subheader("Loss Amount by Product")

# Sirf loss-making orders filter karna
loss_orders_df = filtered_df[filtered_df["Profit"] < 0].copy()

# Product wise total loss calculate karna
loss_products = (
    loss_orders_df.groupby("Product_Name")["Profit"]
    .sum()
    .abs()
    .sort_values(ascending=False)
    .head(10)
    .reset_index()
)

# Rename columns
loss_products.columns = ["Product Name", "Total Loss"]

# Show table
st.dataframe(
    loss_products,
    use_container_width=True,
    height=400
)
# ------------------------------------------------
# FOOTER
# ------------------------------------------------
st.markdown("---")
st.markdown("Developed using Python, Pandas, Streamlit and Plotly")
st.markdown("---")
st.markdown(
    "Developed by Shagun Punia using Python, Pandas, Streamlit & Plotly"
)
st.markdown(
    """
    <style>
    section[data-testid="stSidebar"] {
        background-color: #101b33;
    }
    </style>
    """,
    unsafe_allow_html=True
)